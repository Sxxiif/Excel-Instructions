Attribute VB_Name = "AttendanceMacros"
' ============================================================
'  LogThisWeek  -  commits the ENTER weekly grid into the LOG
'  Reads Name / In / Out / Dept under each day, writes dated
'  rows to the first empty line of LOG, then (optionally) clears
'  the grid and advances the week by 7 days.
'
'  Grid layout it expects on the ENTER sheet:
'    - Week-start (Monday) date in cell C1
'    - Each day = 5 columns: Name, In, Out, Dept, spacer
'      Mon starts col A(1), Tue F(6), Wed K(11), Thu P(16),
'      Fri U(21), Sat Z(26), Sun AE(31)
'    - Data rows 5 through 19 (15 slots per day)
'  LOG columns: A Date | B Name | C In | D Out | E Dept | F Hours
' ============================================================
Option Explicit

Public Sub LogThisWeek()
    Dim wsE As Worksheet, wsL As Worksheet
    Const FIRST_ROW As Long = 5      ' first entry row on the grid
    Const SLOTS As Long = 15         ' entry rows per day
    Const DAYS As Long = 7

    On Error GoTo Fail
    Set wsE = ThisWorkbook.Worksheets("ENTER")
    Set wsL = ThisWorkbook.Worksheets("LOG")

    ' --- validate week-start date ---
    If Not IsDate(wsE.Range("C1").Value) Then
        MsgBox "Enter a valid 'Week Starting (Mon)' date in cell C1 first.", vbExclamation, "Log this week"
        Exit Sub
    End If
    Dim wkStart As Date
    wkStart = wsE.Range("C1").Value

    Dim lastRow As Long
    lastRow = wsL.Cells(wsL.Rows.Count, 1).End(xlUp).Row
    If lastRow < 1 Then lastRow = 1  ' keep header on row 1

    Dim d As Long, s As Long, c0 As Long, rr As Long, added As Long
    Dim nm As Variant, tin As Variant, tout As Variant, dp As Variant

    Application.ScreenUpdating = False
    For d = 0 To DAYS - 1
        c0 = 1 + d * 5               ' Name column for this day
        For s = 0 To SLOTS - 1
            rr = FIRST_ROW + s
            nm = wsE.Cells(rr, c0).Value
            If Len(Trim(CStr(nm))) > 0 Then
                tin = wsE.Cells(rr, c0 + 1).Value
                tout = wsE.Cells(rr, c0 + 2).Value
                dp = wsE.Cells(rr, c0 + 3).Value

                lastRow = lastRow + 1
                With wsL
                    .Cells(lastRow, 1).Value = wkStart + d
                    .Cells(lastRow, 1).NumberFormat = "yyyy-mm-dd"
                    .Cells(lastRow, 2).Value = nm
                    .Cells(lastRow, 3).Value = tin
                    .Cells(lastRow, 3).NumberFormat = "h:mm"
                    .Cells(lastRow, 4).Value = tout
                    .Cells(lastRow, 4).NumberFormat = "h:mm"
                    .Cells(lastRow, 5).Value = dp
                    If IsNumeric(tin) And IsNumeric(tout) Then
                        .Cells(lastRow, 6).Value = (CDbl(tout) - CDbl(tin)) * 24
                    Else
                        .Cells(lastRow, 6).Value = ""
                    End If
                    .Cells(lastRow, 6).NumberFormat = "0.0"
                End With
                added = added + 1
            End If
        Next s
    Next d
    Application.ScreenUpdating = True

    If added = 0 Then
        MsgBox "No names found in the grid - nothing was logged.", vbInformation, "Log this week"
        Exit Sub
    End If

    Dim ans As VbMsgBoxResult
    ans = MsgBox(added & " row(s) added to LOG." & vbCrLf & vbCrLf & _
                 "Clear the weekly grid and move to next week?", _
                 vbYesNo + vbQuestion, "Log this week")
    If ans = vbYes Then
        For d = 0 To DAYS - 1
            c0 = 1 + d * 5
            wsE.Range(wsE.Cells(FIRST_ROW, c0), wsE.Cells(FIRST_ROW + SLOTS - 1, c0 + 3)).ClearContents
        Next d
        wsE.Range("C1").Value = wkStart + 7   ' advance to next Monday
    End If

    MsgBox "Done. LOG now has " & (wsL.Cells(wsL.Rows.Count, 1).End(xlUp).Row - 1) & " total records.", _
           vbInformation, "Log this week"
    Exit Sub

Fail:
    Application.ScreenUpdating = True
    MsgBox "Something went wrong: " & Err.Description, vbCritical, "Log this week"
End Sub
